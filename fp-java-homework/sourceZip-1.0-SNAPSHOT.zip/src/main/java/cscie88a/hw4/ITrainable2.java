package cscie88a.hw4;

import cscie88a.hw2.ActionResult;

/**
 * FI with a return value
 */
@FunctionalInterface
public interface ITrainable2 {

    ActionResult doAnyTrick();
}
