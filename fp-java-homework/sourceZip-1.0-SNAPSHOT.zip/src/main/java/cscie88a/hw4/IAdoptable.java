package cscie88a.hw4;

@FunctionalInterface
public interface IAdoptable {

    public boolean readyForAdoption();
}
