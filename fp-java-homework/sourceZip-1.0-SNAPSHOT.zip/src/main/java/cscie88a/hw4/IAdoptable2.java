package cscie88a.hw4;

@FunctionalInterface
public interface IAdoptable2 {

    public boolean readyForAdoption(boolean healthCheckDone);
}
