package cscie88a.hw4;

public class DogFP extends AbstractAnimalFP {

    // dogs are always of type DOG
    public DogFP(String name){
        super(AnimalType.DOG, name);
    }
    // we will leave all default functionality as is
}
