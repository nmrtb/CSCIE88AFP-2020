package cscie88a.hw4;

public enum AnimalType {
    CAT,
    DOG,
    HEDGEHOG,
    TIGER
}
