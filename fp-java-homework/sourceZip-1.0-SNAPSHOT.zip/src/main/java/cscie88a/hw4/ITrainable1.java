package cscie88a.hw4;

/**
 * FI with no arguments and no return values
 */
@FunctionalInterface
public interface ITrainable1 {

    void doAnyTrick();
}
