package cscie88a.hw4;

import cscie88a.hw2.ActionResult;

/**
 * FI with multiple arguments
 */
@FunctionalInterface
public interface ITrainable3 {

    ActionResult doManyTricks(String trick1, String trick2);
}
