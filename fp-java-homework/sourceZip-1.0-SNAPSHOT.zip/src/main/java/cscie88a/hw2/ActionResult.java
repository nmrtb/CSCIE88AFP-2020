package cscie88a.hw2;

public enum ActionResult {
	SUCCESS,
	FAILURE
}
